from django.apps import AppConfig


class Restserviceesse3Config(AppConfig):
    name = 'RestServiceEsse3'

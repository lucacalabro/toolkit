from django.shortcuts import render
from django.http import HttpResponse

# Richieste per rest service
import requests
from requests_auth import Basic

# Create your views here.
user = "forms"
passwd = "yg7dpwn0.pdk69gn"

urlStudent = ["https://equipe.si.unimib.it/equipe-web/webresources/ActionFormsStudente/matricola/"
    , "https://equipe.si.unimib.it/equipe-web/webresources/ActionFormsStudente/codFis/"
    , "https://equipe.si.unimib.it/equipe-web/webresources/ActionFormsStudente/emailAte/"]
urlEmployee = ["https://equipe.si.unimib.it/equipe-web/webresources/ActionFormsRu/matricola/"
    , "https://equipe.si.unimib.it/equipe-web/webresources/ActionFormsRu/codFis/"
    , "https://equipe.si.unimib.it/equipe-web/webresources/ActionFormsRu/email/"]
# pip install requests-auth

#I valori restituiti sono liste di dizionari



def studentematricola(request, matricola):
    response = requests.get(urlStudent[0] + str(matricola), auth=Basic(user, passwd))

    response_json = response.json()

    #return HttpResponse(response_json[0]["cdsDes"])
    return HttpResponse(len(response_json))




def testRest(request):
    response = requests.get(urlEmployee[2] + 'luca.calabro@unimib.it', auth=Basic(user, passwd))

    response_json = response.json()

    #return HttpResponse(response_json[0]["idAb"])
    return HttpResponse(response_json)
